package com.lib.app.dto;

import lombok.Data;

@Data
public class Spot {
	
	private String SNo;
	private String MTime;
	private String ATime;
	private String ETime;

}
